// Setting variables
localStorage.setItem('collectedApple', false);
localStorage.setItem('collectedPineapple', false);
localStorage.setItem('collectedHoney', false);

localStorage.setItem('applePathComplete', false);
localStorage.setItem('pineapplePathComplete', false);
localStorage.setItem('honeyPathComplete', false);

localStorage.setItem('num_collected', 0);